__all__ = ['befunge93', 'funge98', 'funge98opt']

.. _NULL:

``"NULL"`` Funge-98 Null Fingerprint
---------------------------------------

:Fingerprint ID: 0x4e554c4c

This fingerprint, from `Cat's Eye Technologies`__, overrides all fingerprint commands to default. It provides the following commands:

__ http://catseye.tc/projects/funge98/library/NULL.html

``A`` to ``Z`` : ---
    Reflects.

